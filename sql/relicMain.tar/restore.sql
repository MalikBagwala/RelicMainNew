--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.4
-- Dumped by pg_dump version 10.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.smartphone DROP CONSTRAINT smartphone_bid_fkey;
ALTER TABLE ONLY public.cartitems DROP CONSTRAINT cartitems_pid_fkey;
ALTER TABLE ONLY public.cartitems DROP CONSTRAINT cartitems_id_fkey;
ALTER TABLE ONLY public.cart DROP CONSTRAINT cart_uid_fkey;
ALTER TABLE ONLY public.relic_user DROP CONSTRAINT un_email;
ALTER TABLE ONLY public.smartphone DROP CONSTRAINT smartphone_pkey;
ALTER TABLE ONLY public.relic_user DROP CONSTRAINT relic_user_pkey;
ALTER TABLE ONLY public.rand DROP CONSTRAINT rand_pkey;
ALTER TABLE ONLY public.cartitems DROP CONSTRAINT cartitems_pkey;
ALTER TABLE ONLY public.cart DROP CONSTRAINT cart_pkey;
ALTER TABLE ONLY public.brand DROP CONSTRAINT brand_pkey;
ALTER TABLE ONLY public.admins DROP CONSTRAINT admins_pkey;
ALTER TABLE ONLY public.admins DROP CONSTRAINT admins_aemail_key;
ALTER TABLE public.smartphone ALTER COLUMN pid DROP DEFAULT;
ALTER TABLE public.relic_user ALTER COLUMN uid DROP DEFAULT;
ALTER TABLE public.cartitems ALTER COLUMN cid DROP DEFAULT;
ALTER TABLE public.cart ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.brand ALTER COLUMN bid DROP DEFAULT;
ALTER TABLE public.admins ALTER COLUMN aid DROP DEFAULT;
DROP TABLE public.stud;
DROP SEQUENCE public.smartphone_pid_seq;
DROP TABLE public.smartphone;
DROP SEQUENCE public.relic_user_uid_seq;
DROP TABLE public.relic_user;
DROP TABLE public.rand;
DROP TABLE public.phone;
DROP SEQUENCE public.cartitems_cid_seq;
DROP TABLE public.cartitems;
DROP SEQUENCE public.cart_id_seq;
DROP TABLE public.cart;
DROP SEQUENCE public.brand_bid_seq;
DROP TABLE public.brand;
DROP SEQUENCE public.admins_aid_seq;
DROP TABLE public.admins;
DROP EXTENSION adminpack;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admins (
    aid integer NOT NULL,
    aname character varying(30) NOT NULL,
    aemail text NOT NULL,
    apass text NOT NULL,
    acity character varying(30) NOT NULL,
    apos character varying(20) NOT NULL,
    exp integer
);


ALTER TABLE public.admins OWNER TO postgres;

--
-- Name: admins_aid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admins_aid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admins_aid_seq OWNER TO postgres;

--
-- Name: admins_aid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admins_aid_seq OWNED BY public.admins.aid;


--
-- Name: brand; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.brand (
    bid integer NOT NULL,
    bnm character varying(20) NOT NULL
);


ALTER TABLE public.brand OWNER TO postgres;

--
-- Name: brand_bid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.brand_bid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.brand_bid_seq OWNER TO postgres;

--
-- Name: brand_bid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.brand_bid_seq OWNED BY public.brand.bid;


--
-- Name: cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart (
    id integer NOT NULL,
    uid integer,
    date date,
    checked character(1) DEFAULT 'N'::bpchar NOT NULL,
    delivered character(1) DEFAULT 'N'::bpchar NOT NULL
);


ALTER TABLE public.cart OWNER TO postgres;

--
-- Name: cart_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cart_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cart_id_seq OWNER TO postgres;

--
-- Name: cart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cart_id_seq OWNED BY public.cart.id;


--
-- Name: cartitems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cartitems (
    cid integer NOT NULL,
    id integer,
    pid integer,
    qty integer,
    CONSTRAINT cartitems_qty_check CHECK ((qty < 5))
);


ALTER TABLE public.cartitems OWNER TO postgres;

--
-- Name: cartitems_cid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cartitems_cid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cartitems_cid_seq OWNER TO postgres;

--
-- Name: cartitems_cid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cartitems_cid_seq OWNED BY public.cartitems.cid;


--
-- Name: phone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.phone (
    pno text,
    pnm text,
    padr text,
    ptype text
);


ALTER TABLE public.phone OWNER TO postgres;

--
-- Name: rand; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rand (
    rid integer NOT NULL
);


ALTER TABLE public.rand OWNER TO postgres;

--
-- Name: relic_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.relic_user (
    uid integer NOT NULL,
    uname character varying(50) NOT NULL,
    uemail character varying(255) NOT NULL,
    upass character varying(50) NOT NULL,
    uaddr text,
    ucity character varying(100),
    ustate character varying(100),
    upin integer
);


ALTER TABLE public.relic_user OWNER TO postgres;

--
-- Name: relic_user_uid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.relic_user_uid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.relic_user_uid_seq OWNER TO postgres;

--
-- Name: relic_user_uid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.relic_user_uid_seq OWNED BY public.relic_user.uid;


--
-- Name: smartphone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.smartphone (
    pid integer NOT NULL,
    pname character varying(100) NOT NULL,
    pdesc text NOT NULL,
    pproc character varying(25),
    pdisp character varying(20) NOT NULL,
    ppcam integer NOT NULL,
    pscam integer NOT NULL,
    pram integer NOT NULL,
    pstore integer NOT NULL,
    pbatt integer NOT NULL,
    price double precision NOT NULL,
    pimg character varying(25),
    bid integer,
    qty integer,
    CONSTRAINT smartphone_qty_check CHECK ((qty >= 0))
);


ALTER TABLE public.smartphone OWNER TO postgres;

--
-- Name: smartphone_pid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.smartphone_pid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.smartphone_pid_seq OWNER TO postgres;

--
-- Name: smartphone_pid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.smartphone_pid_seq OWNED BY public.smartphone.pid;


--
-- Name: stud; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stud (
    sno integer,
    snm text,
    scls text
);


ALTER TABLE public.stud OWNER TO postgres;

--
-- Name: admins aid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins ALTER COLUMN aid SET DEFAULT nextval('public.admins_aid_seq'::regclass);


--
-- Name: brand bid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brand ALTER COLUMN bid SET DEFAULT nextval('public.brand_bid_seq'::regclass);


--
-- Name: cart id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart ALTER COLUMN id SET DEFAULT nextval('public.cart_id_seq'::regclass);


--
-- Name: cartitems cid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartitems ALTER COLUMN cid SET DEFAULT nextval('public.cartitems_cid_seq'::regclass);


--
-- Name: relic_user uid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relic_user ALTER COLUMN uid SET DEFAULT nextval('public.relic_user_uid_seq'::regclass);


--
-- Name: smartphone pid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartphone ALTER COLUMN pid SET DEFAULT nextval('public.smartphone_pid_seq'::regclass);


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admins (aid, aname, aemail, apass, acity, apos, exp) FROM stdin;
\.
COPY public.admins (aid, aname, aemail, apass, acity, apos, exp) FROM '$$PATH$$/2875.dat';

--
-- Data for Name: brand; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.brand (bid, bnm) FROM stdin;
\.
COPY public.brand (bid, bnm) FROM '$$PATH$$/2881.dat';

--
-- Data for Name: cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart (id, uid, date, checked, delivered) FROM stdin;
\.
COPY public.cart (id, uid, date, checked, delivered) FROM '$$PATH$$/2883.dat';

--
-- Data for Name: cartitems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cartitems (cid, id, pid, qty) FROM stdin;
\.
COPY public.cartitems (cid, id, pid, qty) FROM '$$PATH$$/2885.dat';

--
-- Data for Name: phone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.phone (pno, pnm, padr, ptype) FROM stdin;
\.
COPY public.phone (pno, pnm, padr, ptype) FROM '$$PATH$$/2877.dat';

--
-- Data for Name: rand; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rand (rid) FROM stdin;
\.
COPY public.rand (rid) FROM '$$PATH$$/2876.dat';

--
-- Data for Name: relic_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.relic_user (uid, uname, uemail, upass, uaddr, ucity, ustate, upin) FROM stdin;
\.
COPY public.relic_user (uid, uname, uemail, upass, uaddr, ucity, ustate, upin) FROM '$$PATH$$/2873.dat';

--
-- Data for Name: smartphone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.smartphone (pid, pname, pdesc, pproc, pdisp, ppcam, pscam, pram, pstore, pbatt, price, pimg, bid, qty) FROM stdin;
\.
COPY public.smartphone (pid, pname, pdesc, pproc, pdisp, ppcam, pscam, pram, pstore, pbatt, price, pimg, bid, qty) FROM '$$PATH$$/2879.dat';

--
-- Data for Name: stud; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stud (sno, snm, scls) FROM stdin;
\.
COPY public.stud (sno, snm, scls) FROM '$$PATH$$/2871.dat';

--
-- Name: admins_aid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admins_aid_seq', 2, true);


--
-- Name: brand_bid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.brand_bid_seq', 12, true);


--
-- Name: cart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cart_id_seq', 33, true);


--
-- Name: cartitems_cid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cartitems_cid_seq', 58, true);


--
-- Name: relic_user_uid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.relic_user_uid_seq', 10, true);


--
-- Name: smartphone_pid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.smartphone_pid_seq', 16, true);


--
-- Name: admins admins_aemail_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_aemail_key UNIQUE (aemail);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (aid);


--
-- Name: brand brand_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brand
    ADD CONSTRAINT brand_pkey PRIMARY KEY (bid);


--
-- Name: cart cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_pkey PRIMARY KEY (id);


--
-- Name: cartitems cartitems_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartitems
    ADD CONSTRAINT cartitems_pkey PRIMARY KEY (cid);


--
-- Name: rand rand_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rand
    ADD CONSTRAINT rand_pkey PRIMARY KEY (rid);


--
-- Name: relic_user relic_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relic_user
    ADD CONSTRAINT relic_user_pkey PRIMARY KEY (uid);


--
-- Name: smartphone smartphone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartphone
    ADD CONSTRAINT smartphone_pkey PRIMARY KEY (pid);


--
-- Name: relic_user un_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relic_user
    ADD CONSTRAINT un_email UNIQUE (uemail);


--
-- Name: cart cart_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_uid_fkey FOREIGN KEY (uid) REFERENCES public.relic_user(uid);


--
-- Name: cartitems cartitems_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartitems
    ADD CONSTRAINT cartitems_id_fkey FOREIGN KEY (id) REFERENCES public.cart(id);


--
-- Name: cartitems cartitems_pid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartitems
    ADD CONSTRAINT cartitems_pid_fkey FOREIGN KEY (pid) REFERENCES public.smartphone(pid);


--
-- Name: smartphone smartphone_bid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartphone
    ADD CONSTRAINT smartphone_bid_fkey FOREIGN KEY (bid) REFERENCES public.brand(bid);


--
-- PostgreSQL database dump complete
--

